package br.com.academiadoflutter.vakinha_burger_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
