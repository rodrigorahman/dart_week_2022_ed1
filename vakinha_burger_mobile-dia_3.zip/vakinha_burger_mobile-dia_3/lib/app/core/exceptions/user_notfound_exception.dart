class UserNotFoundException implements Exception {

}