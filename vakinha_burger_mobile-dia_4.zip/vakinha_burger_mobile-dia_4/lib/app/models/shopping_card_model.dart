
import 'package:vakinha_burger_mobile/app/models/product_model.dart';

class ShoppingCardModel {
  
  int quantity;
  ProductModel product;

  ShoppingCardModel({
    required this.quantity,
    required this.product,
  });
}
