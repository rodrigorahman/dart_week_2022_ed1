
class Constants {
  Constants._();

  static const USER_KEY = '/USER_KEY/';
}